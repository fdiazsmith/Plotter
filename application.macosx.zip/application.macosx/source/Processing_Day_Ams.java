import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Processing_Day_Ams extends PApplet {


Canvas canvas;
JSONObject settings;

/**
*
* @method settings
*/
public void settings( ){

  settings = loadJSONObject("settings.json");

  JSONObject size;
  size = settings.getJSONObject("size");

  size(size.getInt("width"), size.getInt("height"));
   fullScreen( );
}
/**
*
* @method setup
*/
public void setup() {
  
  canvas = new Canvas( "data" );
  canvas.set();
}
/**
*
* @method draw
*/
public void draw( ) {
  clear();
  canvas.update();
}
/**
*
* @method keyReleased
*/
public void keyReleased( ) {
  canvas.released(key);
}

/**
*
* @method keyPressed
*/
public void keyPressed( ) {
  canvas.pressed(key);
}

/**
*
* @method mouseMoved
*/
public void mouseMoved( ) {
  canvas.mouseMoved();
}
/**
*
* @method mousePressed
*/
public void mousePressed() {
  canvas.mousePressed();
}
/**
 * @class Brush
 * - anything that leaves a mark should be handled here.
 */
class Brush {
  int size;
  int scale;
  int brushColor;
  PGraphics pg;
  PShape shp;

  private int radius;
  private int mX,
              mY,
              pX,
              pY;
  private boolean eraser = false;
  private int clearColor  = color(255, 0);

  /**
   * @contructor
   * @param {int} _s - size of the brush
   */
  Brush (int _s) {
    brushColor = color(23);
    scale = 1;
    size = (int)_s/scale;
    radius = size/2;
    pg = createGraphics(width/scale, height/scale);
    shp = createShape();
  }

  /**
   * @method update – change appreances of the brush
   */
  public void update() {
    getMouse();
    if ( mousePressed ) {
      if (mouseButton == LEFT) {
        draw();
      } else if (mouseButton == RIGHT) {
        eraser = true;
        erase();
      }
    }
  }

  /**
   * @method draw – make the trace
   */
  public void draw() {
    pg.beginDraw();
    pg.stroke(brushColor);
    pg.strokeWeight(size);
    pg.smooth();
    pg.line(pX, pY, mX, mY);
    /*
    if we wanted to createshapes that could be revisited or redrawn
    here we would use a PShape to create vertor art instead of pixel based images
    */
    pg.endDraw();
  }

  /**
   * @method erase –
   */
  public void erase() {
    int wMin = mX - radius;
    int wMax = mX + radius;
    int hMin = mY - radius;
    int hMax = mY + radius;
    pg.beginDraw();
    pg.loadPixels();
    for(int x = wMin ; x < wMax ; x++){
      for(int y = hMin ; y < hMax ; y++){
          if( sqrt( pow((mouseX/scale) - x,2)+pow((mouseY/scale) - y,2) ) < radius ){
            // pg.set(x,y,clearColor);
            pg.pixels[x+y*(width/scale)] = clearColor;
          }
      }
    }
    pg.updatePixels();
    pg.endDraw();
  }

  /**
   * @method reset – delete all marks. return to blank 'canvas'
   * @params {boolean} hardReset
   */
  public void reset( boolean hardReset) {
    pX = mouseX;
    pY =  mouseY;
    if(hardReset){
      pg = createGraphics(width, height);
      // HACK: you can't save an empty canvas. so we draw and transparent line
      pg.beginDraw();
      pg.stroke(255, 0);
      pg.line(0, 0, width, 0);
      pg.endDraw();
      shp = createShape();
    }
  }

  /**
   * @method get – returns the brush graphics context
   * @returns {PGraphics} pg
   */
  public PGraphics get() {
    return pg;
  }

  /**
   * @method get – returns the brush graphics context
   * @returns {PGraphics} pg
   */
  public void getMouse() {
    mX = mouseX/scale;
    mY = mouseY/scale;
    pX = pmouseX/scale;
    pY = pmouseY/scale;
  }
}
/**
 * @class Canvas
 * - this class should coordinate between player and brush
 */
class Canvas {
  boolean pressedLastFrame;
  int totalNumberOfFrames;
  Player player;
  int bgCol = color(255, 255, 255);
  boolean hardReset = true;
  PImage current;
  Brush brush;
  PGraphics[] oL = new PGraphics[10];
  PGraphics brushCanvas;
  boolean chosen = false;
  int modalTime = 1300;
  private int modalTimeStamp;


  /**
   * @contructor
   * @param {String} path - path to the data folder were the frames will be stored.
   */
  Canvas ( String path) {
    brush = new Brush(30);
    player = new Player(path);
    totalNumberOfFrames = player.getFileCount( );
    current = createImage( width, height, ARGB );
  }

  /**
   * @method set
   * prepares the canvas to draw the next frame.
   */
  public void set( ) {
    brush.reset(hardReset);
    player.reload();

    totalNumberOfFrames = player.getFileCount( );

  }

  /**
   * @method released – handles keyReleased events
   * @param {char} _key - key just released
   */
  public void released(char _key) {
    if ( _key == 's' ) {
      pressedLastFrame = false;
    }
    else if(_key == 'h' ){
      player.setOnionLayers(3);
    }
    else if ( _key == 'p' ) {
      player.previewWithOnion = false;
    }
  }
  /**
   * @method pressed – handles keyReleased events
   * @param {char} _key - key just pressed
   */
  public void pressed(char _key) {
    if ( _key == 'p' ) {
      player.playing = true;
      player.previewWithOnion = true;
    }
    else if(_key == 's' ){
      save();
    }
    else if(_key == 'r' ){
      brush.reset(hardReset);
    }
    else if(_key == 'h' ){
      player.setOnionLayers(10);
    }
    else if(_key == 'o'){
      player.seek(-2);
    }

  }
  /**
   * @method mouseMoved
   */
  public void mouseMoved() {
    // if(player.playing){
    //   player.stop();
    // }
    // if( !chosen ) {
    //   fill(50, 50);
    //   if(mouseX > width/2){
    //     rect(width/2,0,width, height);
    //   }
    //   else{
    //     rect(0,0,width/2, height);
    //   }
    // }
  }
  /**
   * @method mousePressed
   */
  public void mousePressed() {
    if( !chosen ) {
      if(mouseX > width/2){
        hardReset = false;
      }
      else{
        hardReset = true;
      }
      set();
      chosen = true;
    }
  }

  /**
   * @method update - draws and displays
   */
  public void update( ) {
    background(bgCol);
    if(player.playing){
      player.play();
    }
    else if(!chosen){
      brushCanvas = brush.get();
      image(brushCanvas, 0, 0, width, height);
      choose(!chosen);
    }
    else{
      displayUI();

      brush.update( );

      player.onion();
      brushCanvas = brush.get();
      image(brushCanvas, 0, 0, width, height);
    }
  }
  /**
   * @class displayUI – 
   */
  public void displayUI( ) {
    message("Animation duration: "+player.getTimeCode(), width*.015f, height*0.015f);
    if(modalTimeStamp + modalTime > millis() ){
      modal("Frame Saved", (millis()-modalTimeStamp*1.0f)/modalTime*1.0f );

    }
  }
  /**
   * @class save -
   */
  public void save( ) {
    // modal("Frame Saved");
    chosen = false;
    modalTimeStamp = millis();
    totalNumberOfFrames++;
    brushCanvas.save("data/"+totalNumberOfFrames+".png");
    pressedLastFrame = true;

  }
  /**
   * @class modal – 
   */
  public void modal( String message, float normal ) {
    float alpha = 1-(normal*normal);
    textAlign(CENTER, CENTER);
    fill(50, alpha*150);
    rect(0,0,width, height);
    fill(255, alpha*255);
    textSize(132);
    text(message, width/2, height/2);
  }
  /**
   * @class message – 
   */
  public void message( String message, float x, float y ) {
    textAlign(LEFT, CENTER);
    fill(30, 180);
    textSize(16);
    text(message, (int)x, (int)y );
  }
  /**
   * @class choose – 
   */
  public boolean choose( boolean show ) {
    if(show){

      fill(44, 46, 27, 100);
      rect(0,0,width, height);

      fill(255);
      textAlign(CENTER, CENTER);
      textSize(26);
      text("START WITH EMPTY FRAME", width*.25f, height/2 );
      text("COPY LAST FRAME", width*.75f, height/2 );

      textAlign(CENTER, CENTER);
      textSize(132);
      text("Frame Saved", width/2, height*.15f);



      textSize(30);
      text("FYI you can also erase with the back of the pen", width/2, height*.85f);
    }
    return true;
  }
}
/**
 * @class Player
 *  - anything that has to do with frames should be handled here
 * [custom event listeners](https://forum.processing.org/one/topic/custom-events-event-listener.html)
 */
class Player {
  File[] files;
  String path;
  PImage[] onionLayers = new PImage[10];
  boolean playing = false;
  int frame = 1;
  int framesPerSecond;
  int lastFrameTimeStamp;
  int onionLayerCount = 3;
  boolean onionLayersAvailable = false;
  boolean previewWithOnion = false;
  // This is none of your business, it is private parts!
  private int oLCount = 3;
  private float fpsInterval = 0;
  private static final boolean DEBUG = false;

  /**
   * @contructor
   * @param {String} path - path to the data folder were the frames will be stored.
   */
  Player ( String _path ) {
    path = _path;
    files = listFiles( _path );
    setFPS(10);
  }

  /**
   * @method play
   */
  public void play( ) {
    showFrame( frame );
    if(lastFrameTimeStamp + fpsInterval < millis()){
      frame++;
      lastFrameTimeStamp = millis();
    }
  }
  /**
   * @method seek
   * @params seconds -
   * if negative it starts at the end and substracts seconds
   * if positive is simply starts at 0
   */
  public void seek( int seconds ) {
    if( seconds < 0 ){
      frame = getFileCount() + (seconds * framesPerSecond);
      frame = frame <= 1 ? 1: frame;
    }
    else{
      frame = seconds*framesPerSecond;
    }
    playing = true;
  }

  /**
   * @method showFrame
   * the reason this in almos a repeated version of onion is because we want to optimize
   * and only load images every times we save and not every frame
   */
  public void showFrame( int frame ) {
    int totalFrames = getFileCount( );
    tint(255, 255);
    if( frame < totalFrames ){
      if(previewWithOnion) showGosted();
      PImage currentFrame = loadImage("data/"+frame+".png");
      image(currentFrame, 0, 0);//, width, height);
    }
    else{
      stop( );
    }
  }

  /**
   * @method showGosted
   *
   */
  public void showGosted( ) {

    for (int i = 0; i < oLCount; i++) {
      float alpha = 1 - (i*1.0f/oLCount*1.0f);
      tint(255, (alpha*alpha) * 100);
      int f = frame-i >=1?frame-i:1;
      PImage currentFrame = loadImage("data/"+f+".png");
      image(currentFrame, 0, 0);//, width, height);
    }
    tint(255, 255);
  }

  /**
   * @method stop
   * prepares the canvas to draw the next frame.
   */
  public void stop( ) {
    playing = false;
    frame = 1;
  }

  /**
   * @method set
   * prepares the canvas to draw the next frame.
   */
  public void set( ) {
    int fileCount = getFileCount()>10? 10 : getFileCount() ;
    if( fileCount >= 0 ){
      onionLayersAvailable = true;
      oLCount = fileCount>3? oLCount: fileCount;
      if( DEBUG ) println("Get number of file !! ", fileCount);

      for (int i = 0; i <= fileCount-1; i++) {
        if( DEBUG ) println(i+"  data/"+(getFileCount()-i)+".png");
        onionLayers[i] = loadImage("data/"+(getFileCount()-i)+".png");
      }

    }
  }

  /**
   * @method onion – display onion skin layer for reference
   */
  public void onion( ) {
    if( onionLayersAvailable ){
      for (int i = 0; i < oLCount; i++) {
        float alpha = 1 - (i*1.0f/oLCount*1.0f);
        tint(255, alpha * 150);
        image(onionLayers[i], 0, 0);//, width, height);
      }
      tint(255, 255);
    }
  }
  /**
   * @method setOnionLayers
   * @param {int} count
   */
  public void setOnionLayers( int count ) {
    oLCount = getFileCount() < 10 ? getFileCount() : count;
  }

  /**
   * @method getFileCount – return number of files in the specified data folder
   * @return {int} filecount
   */
  public int getFileCount( ) {
    return files.length-1;
  }

  /**
   * @method reload – updates file list array
   */
  public void reload( ) {
    files = listFiles( path );
    set( );
  }

  /**
   * @method setFPS –
   */
  public float setFPS( int frames ) {
    files = listFiles( path );
    framesPerSecond = frames;
    fpsInterval = 1000/framesPerSecond;
    return fpsInterval;
  }
  /**
   * @method getMinutes –
   */
  public float getMinutes(  ) {
    return floor((getFileCount()/framesPerSecond)/60);
  }
  /**
   * @method getSeconds –
   */
  public float getSeconds(  ) {
    return floor((getFileCount()/framesPerSecond)%60);
  }
  /**
   * @method getTimeCode –
   */
  public String getTimeCode(  ) {
    String _minutes = getMinutes()<10? "0"+(int)getMinutes():(int)getMinutes()+"";
    String _seconds = getSeconds()<10? "0"+(int)getSeconds():(int)getSeconds()+"";
    return  _minutes+":"+_seconds;
  }

  /**
   * @method listFiles – get
   * @returns {File[]} - array of filepath.
   */
  public File[] listFiles( String dir ) {
    File file = new File( sketchPath() + "/"+dir );
    if ( file.isDirectory() ) {
      File[] files = file.listFiles( );
      return files;
    } else {
      // If it's not a directory
      return null;
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "Processing_Day_Ams" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
